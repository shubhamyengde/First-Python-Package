from yengde import power, average, SayHello
SayHello()
x=power(3,2)
print("power(3,2) : ", x)