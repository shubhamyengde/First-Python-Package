# yengde

A Python package to get number table.

## Usage

Following query on terminal will provide you the table of number 9

```
yengde no 9
```